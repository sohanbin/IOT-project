#include "main.h"

void on_center_button() {
}

void initialize() {
}

// the following functions don't work presently because comp. control
// hasn't been fully implemented
void disabled() {}
void competition_initialize() {}
